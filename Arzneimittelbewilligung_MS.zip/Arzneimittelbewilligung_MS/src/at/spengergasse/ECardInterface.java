package at.spengergasse;

import java.rmi.RemoteException;

import at.chipkarte.client.abs.soap.AnfrageAntwort;
import at.chipkarte.client.abs.soap.BewilligungsAnfrage;
import at.chipkarte.client.abs.soap.FilterKriterien;
import at.chipkarte.client.abs.soap.FolgeverordnungsAusstellungsErgebnis;
import at.chipkarte.client.abs.soap.FolgeverordnungsAusstellungsParameter;
import at.chipkarte.client.abs.soap.IAbsService;
import at.chipkarte.client.abs.soap.LangzeitbewilligungsAbfrageErgebnis;
import at.chipkarte.client.abs.soap.Rueckantwort;
import at.chipkarte.client.abs.soap.StatusBewilligungsAnfrage;
import at.chipkarte.client.abs.soap.exceptions.AbsExceptionContent;
import at.chipkarte.client.abs.soap.exceptions.InvalidParameterBewilligungsanfrageExceptionContent;
import at.chipkarte.client.abs.soap.exceptions.InvalidParameterGetAnfrageStatusExceptionContent;
import at.chipkarte.client.abs.soap.exceptions.InvalidParameterRueckantwortExceptionContent;
import at.chipkarte.client.base.soap.BaseProperty;
import at.chipkarte.client.base.soap.Card;
import at.chipkarte.client.base.soap.CardReader;
import at.chipkarte.client.base.soap.DialogsInfo;
import at.chipkarte.client.base.soap.GdaMa;
import at.chipkarte.client.base.soap.GinaVersion;
import at.chipkarte.client.base.soap.IBaseService;
import at.chipkarte.client.base.soap.Message;
import at.chipkarte.client.base.soap.MessagePollResult;
import at.chipkarte.client.base.soap.ProduktInfo;
import at.chipkarte.client.base.soap.Property;
import at.chipkarte.client.base.soap.ReaderStatusResult;
import at.chipkarte.client.base.soap.StatusInformationen;
import at.chipkarte.client.base.soap.SvtProperty;
import at.chipkarte.client.base.soap.VertragsDaten;
import at.chipkarte.client.base.soap.VertragspartnerV2;
import at.chipkarte.client.base.soap.exceptions.AccessExceptionContent;
import at.chipkarte.client.base.soap.exceptions.CardExceptionContent;
import at.chipkarte.client.base.soap.exceptions.DialogExceptionContent;
import at.chipkarte.client.base.soap.exceptions.ServiceExceptionContent;

public class ECardInterface implements IBaseService, IAbsService{

	@Override
	public LangzeitbewilligungsAbfrageErgebnis[] abfragenLangzeitbewilligung(String dialogId, String sVNRPatient,
			String cardReaderId)
			throws RemoteException, InvalidParameterBewilligungsanfrageExceptionContent, AccessExceptionContent,
			ServiceExceptionContent, DialogExceptionContent, AbsExceptionContent, CardExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BewilligungsAnfrage ermittelnPatientenDaten(String dialogId, String svNummer, String svtCode,
			String ekvkNummer, String geschlecht, String nachname, String vorname, String antragstyp,
			String cardReaderId)
			throws RemoteException, InvalidParameterBewilligungsanfrageExceptionContent, AccessExceptionContent,
			ServiceExceptionContent, DialogExceptionContent, AbsExceptionContent, CardExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Rueckantwort getRueckantwort(String dialogId, String anfrageId)
			throws RemoteException, AccessExceptionContent, ServiceExceptionContent, DialogExceptionContent,
			AbsExceptionContent, InvalidParameterRueckantwortExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public StatusBewilligungsAnfrage[] getStatusBewilligungsAnfragen(String dialogId, FilterKriterien filterkriterien)
			throws RemoteException, AccessExceptionContent, ServiceExceptionContent,
			InvalidParameterGetAnfrageStatusExceptionContent, DialogExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public StatusBewilligungsAnfrage[] getStatusPatientBewilligungsAnfragen(String dialogId, String svNummer,
			String nachname, String vorname, String cardReaderId) throws RemoteException,
			InvalidParameterBewilligungsanfrageExceptionContent, AccessExceptionContent, ServiceExceptionContent,
			InvalidParameterGetAnfrageStatusExceptionContent, DialogExceptionContent, CardExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AnfrageAntwort sendenAnfrage(String dialogId, BewilligungsAnfrage anfrage, String cardReaderId,
			byte[] attachment)
			throws RemoteException, InvalidParameterBewilligungsanfrageExceptionContent, AccessExceptionContent,
			ServiceExceptionContent, DialogExceptionContent, AbsExceptionContent, CardExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FolgeverordnungsAusstellungsErgebnis sendenFolgeverordnung(String dialogId,
			FolgeverordnungsAusstellungsParameter ausstellungsParameter, String cardReaderId)
			throws RemoteException, InvalidParameterBewilligungsanfrageExceptionContent, AccessExceptionContent,
			ServiceExceptionContent, DialogExceptionContent, AbsExceptionContent, CardExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public VertragspartnerV2 authenticateDialog(String dialogId, String cin, String pin, String cardReaderId)
			throws RemoteException, ServiceExceptionContent, DialogExceptionContent, CardExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public VertragspartnerV2 authenticateDialogEnt(String dialogId)
			throws RemoteException, ServiceExceptionContent, DialogExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void changePin(String cardReaderId, String cin, String oldPin, String newPin)
			throws RemoteException, ServiceExceptionContent, CardExceptionContent {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changePinWithPuk(String cardReaderId, String cin, String puk, String newPin)
			throws RemoteException, ServiceExceptionContent, CardExceptionContent {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Property[] checkStatus(String dialogId)
			throws RemoteException, ServiceExceptionContent, DialogExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void closeDialog(String dialogId) throws RemoteException, ServiceExceptionContent, DialogExceptionContent {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String createDialog(String cardReaderId, ProduktInfo produktInfo, String extUID, Boolean pushMessageEnabled)
			throws RemoteException, ServiceExceptionContent, DialogExceptionContent, CardExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String createDialogEnt(String cardReaderId, ProduktInfo produktInfo, String extUID, String vpNummer,
			Boolean pushMessageEnabled)
			throws RemoteException, ServiceExceptionContent, DialogExceptionContent, CardExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer doCardTest(String cardReaderId)
			throws RemoteException, ServiceExceptionContent, CardExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String[] getBerechtigungen(String dialogId)
			throws RemoteException, ServiceExceptionContent, DialogExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Card getCardData(String cardReaderId) throws RemoteException, ServiceExceptionContent, CardExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CardReader[] getCardReaders() throws RemoteException, ServiceExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Property[] getExtendedCardData(String cardReaderId, String CIN)
			throws RemoteException, ServiceExceptionContent, CardExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BaseProperty[] getFachgebiete() throws RemoteException, ServiceExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BaseProperty[] getFachgebieteByOrdId(String dialogId, String ordId, String taetigkeitsBereichId)
			throws RemoteException, ServiceExceptionContent, DialogExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DialogsInfo getFreeDialogs() throws RemoteException, ServiceExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public StatusInformationen getGinaAndServiceavailabilityInformation()
			throws RemoteException, ServiceExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GinaVersion getGinaSoftwareVersion() throws RemoteException, ServiceExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Message[] getMessages(String dialogId, Boolean newOnly)
			throws RemoteException, ServiceExceptionContent, DialogExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer getMinMsgPollingIntervall(String dialogId)
			throws RemoteException, ServiceExceptionContent, DialogExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ReaderStatusResult getReaderStatusEvents(String handle, String[] cardReaderId, Integer timeOut)
			throws RemoteException, ServiceExceptionContent, CardExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SvtProperty[] getSVTs() throws RemoteException, ServiceExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BaseProperty[] getStaaten() throws RemoteException, ServiceExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public VertragsDaten[] getVertraege(String dialogId)
			throws RemoteException, ServiceExceptionContent, DialogExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MessagePollResult pollMessages(String dialogId, String suchzeitpunkt)
			throws RemoteException, ServiceExceptionContent, DialogExceptionContent {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void releaseCardReader(String cardReaderId)
			throws RemoteException, ServiceExceptionContent, CardExceptionContent {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setCardReader(String dialogId, String cardReaderId)
			throws RemoteException, ServiceExceptionContent, DialogExceptionContent, CardExceptionContent {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setDialogAddress(String dialogId, String ordinationId, String taetigkeitsBereichId, String elgaRolle,
			GdaMa gdaMa, String prozess) throws RemoteException, ServiceExceptionContent, DialogExceptionContent {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void uebersiedelnOrdination(String dialogId, String ordinationId, Boolean forceUebersiedlung)
			throws RemoteException, ServiceExceptionContent, DialogExceptionContent {
		// TODO Auto-generated method stub
		
	}

}
