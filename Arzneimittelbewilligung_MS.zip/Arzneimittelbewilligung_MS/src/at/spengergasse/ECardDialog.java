package at.spengergasse;

import at.chipkarte.client.base.soap.BaseServiceLocator;
import at.chipkarte.client.base.soap.Card;
import at.chipkarte.client.base.soap.CardReader;
import at.chipkarte.client.base.soap.IBaseService;
import at.chipkarte.client.base.soap.Ordination;
import at.chipkarte.client.base.soap.ProduktInfo;
import at.chipkarte.client.base.soap.VertragspartnerV2;

public class ECardDialog {

	public static void main(String[] args) {
		BaseServiceLocator bsl = new BaseServiceLocator();
		try{
			IBaseService bs = bsl.getbase_15();
			CardReader[] cra = bs.getCardReaders();
			System.out.println(cra[0].getId());
			ProduktInfo mproduktinfo = new ProduktInfo();
			mproduktinfo.setProduktId(3);
			mproduktinfo.setProduktVersion("1");
			
			Card cda = bs.getCardData(cra[0].getId());
			String dialog = bs.createDialog(cra[0].getId(), mproduktinfo, null, false);
			
			VertragspartnerV2 vertragspartner = bs.authenticateDialog(dialog, null, "0000", cra[0].getId());
			Ordination[] ordination = vertragspartner.getOrdination();
			
			bs.setDialogAddress(dialog, ordination[0].getOrdinationId(), ordination[0].getTaetigkeitsBereich(0).getId(), null, null, null);
			bs.closeDialog(dialog);
			
			
			System.out.println(dialog);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
