package at.spengergasse;

public class ECardArzneimittel {

	public static void main(String[] args){
		
	}
}
